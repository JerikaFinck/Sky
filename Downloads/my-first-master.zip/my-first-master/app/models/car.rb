class Car < ApplicationRecord
end
